node scripts/web-server.js
